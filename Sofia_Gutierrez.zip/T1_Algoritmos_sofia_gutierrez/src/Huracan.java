import processing.core.PApplet;
import processing.core.PVector;

public class Huracan extends Precipitacion{
	
	private PVector dir;
	private boolean per;
	
	public Huracan(PApplet app, int cant) {
		super(app, cant);
		dir = new PVector();
		per=false;
		
		for (int i = 0; i <= cant; i++) {
			particulas.add(new Hur(app, tam, 0,67,255));
		}
	}
	
	@Override
	public void pintar() {
		for (Particula h : particulas) {
			h.pintar();
			if(per)h.perseguir(dir.x, dir.y);
		}
	}
	
	public void act(PVector pVector) {
		dir=pVector;
	}

	public boolean isPer() {
		return per;
	}

	public void setPer(boolean per) {
		this.per = per;
	}



	public class Hur extends Particula {
		
		public Hur(PApplet app, int tam, int r, int g, int b) {
			super(app, tam, r, g, b);
			dir = new PVector(app.random(0,1200),app.random(0,700));
		}
		
		@Override
		public void pintar() {
			app.fill(106, 43, 255);
			poligono(dir.x, dir.y, 10, 3);
		}

	}


}
