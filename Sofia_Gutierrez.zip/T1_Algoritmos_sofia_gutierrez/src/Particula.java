import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PVector;

public abstract class Particula{
	
	protected PApplet app;
	protected int tam, r, g, b, opa;
	protected float vel;
	protected PVector dir;
	
	public Particula(PApplet app, int tam, int r, int g, int b) {
		this.app=app;
		this.r=r;
		this.g=g;
		this.b=b;
		this.tam=tam;
		
		vel= app.random(2,5);
		opa=100;
		dir = new PVector(app.random(0,1200),app.random(-700,0));
	}
	
	public void pintar() {
		app.ellipseMode(PConstants.CENTER);
		app.noStroke();
		app.fill(r,g,b,opa);
		app.ellipse(dir.x, dir.y, tam, tam);
	}
	
	public void mover() {
		dir.y += vel;
		opa = (int) PApplet.map(dir.y, -30, 700, 100, 20);
		
		regresar();
	}
	
	public void mover2() {
		dir.x += vel;
		opa = (int) PApplet.map(dir.x, 0, 1200, 100, 20);
		
		regresar2();
	}
	
	public void regresar2() {
		if (dir.x >= 1200) {
			vel*=-1;
		}
		
		if (dir.x <= 1) {
			vel*=-1;
		}
	}
	
	public void regresar() {
		if (dir.y >= 700) {
			dir.y=-30;
		}
	}
	
	public void poligono(float x, float y, float radio, int npuntos) {
		float angle = PConstants.TWO_PI / npuntos;
		app.shapeMode(PApplet.CENTER);
		app.beginShape();
		for (float i = 0; i < PConstants.TWO_PI; i += angle) {
			float sx = x + PApplet.cos(i) * radio;
			float sy = y + PApplet.sin(i) * radio;
			app.vertex(sx, sy);
		}
		app.endShape(PConstants.CLOSE);
	}

	public PVector getDir() {
		return dir;
	}

	public void setDir(PVector dir) {
		this.dir = dir;
	}
	
	public void perseguir(float x, float y) {
		PVector result = new PVector(x,y).sub(dir);
		result.normalize();
		result.mult(vel);
		dir.add(result);
	}

	public float getVel() {
		return vel;
	}

	public void setVel(float f) {
		if(vel+f>=-5)this.vel=f;
	}

	public int getTam() {
		return tam;
	}

	public void setTam(int tam) {
		this.tam = tam;
	}
	
	

}
