import processing.core.PApplet;
import processing.core.PVector;

public class Viento extends Precipitacion{
	
	private boolean ventear;

	public Viento (PApplet app, int cant) {
		super(app, cant);
		ventear=false;
		for (int i = 0; i <= cant; i++) {
			Particula p = new Gota(app, tam, 226, 66, 244 );
			p.setDir(new PVector(30,app.random(700)));
			particulas.add(p);
		}
	}
	
	@Override
	public void pintar() {
		for (Particula particula : particulas) {
			particula.pintar();
			if(ventear)particula.mover2();
		}
	}

	public boolean getVentear() {
		return ventear;
	}

	public void setVentear(boolean ventear2) {
		ventear=ventear2;
	}

}
