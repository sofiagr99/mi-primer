import processing.core.PApplet;

public class Gota extends Particula {

	public Gota(PApplet app, int tam, int r, int g, int b) {
		super(app, tam, r, g, b);
	}
}
