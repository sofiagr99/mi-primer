import processing.core.PApplet;
import processing.core.PVector;
import sun.awt.WindowClosingListener;

public class Main extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Main");
	}

	private Logica log;

	@Override
	public void settings() {
		size(1200, 700);
		// fullScreen();
	}

	@Override
	public void setup() {
		log = new Logica(this);
	}

	@Override
	public void draw() {
		background(255);
		log.ejecucion();
	}

	@Override
	public void mousePressed() {
		if (log.getPantalla() == 1) {
			log.ventear();
		}
		
		if (log.getPantalla() == 4) {
			log.valHuracan();
		}
		
		if (log.getPantalla() == 7) {
			log.valNieve();
		}
		
		log.guardarTxt();
	}

	@Override
	public void keyPressed() {
		switch (key) {
		case 'l':
			log.setPantalla(0); // lluvia
			break;

		case 't':
			log.setPantalla(1); // viento
			break;

		case 'f':
			log.setPantalla(2); // flor
			break;

		case 'm':
			log.setPantalla(3); // tornado
			break;

		case 'a':
			log.setPantalla(4); // huracan
			break;

		case 'w':
			log.setPantalla(5); // oto�o
			break;

		case 'n':
			log.setPantalla(6); // verano
			break;

		case 'c':
			log.setPantalla(7); // invierno
			break;
		}

		// Para lanzar rayos
		if (key == ' ' && log.getPantalla() == 0) {
			log.setTormenta(!log.getTormenta());
			log.guardarTxt();
		}
		
		//Hace girar los petalos de la flor
		if (keyCode == ENTER && log.getPantalla() == 2) {
			log.girar();
			log.guardarTxt();
		}

		//Movimientos del tornado
		if (log.getPantalla() == 3) {
			if (keyCode == LEFT) {
				log.moveTor(new PVector(log.getTor().getDir().x - 5 , log.getTor().getDir().y));
			}

			if (keyCode == RIGHT) {
				log.moveTor(new PVector(log.getTor().getDir().x + 5 , log.getTor().getDir().y));
			}
			log.guardarTxt();
		}
		
		//Aumento de vel del otono
		if (log.getPantalla() == 5) {
			if (keyCode == LEFT) {
				log.moveOto(-1);
			}

			if (keyCode == RIGHT) {
				log.moveOto(1);
			}
			
			log.guardarTxt();
		}
		
		//Agrandar las hojas del verano
		if (log.getPantalla() == 6) {
			if (keyCode == LEFT) {
				log.AgranVer(-1);
			}

			if (keyCode == RIGHT) {
				log.AgranVer(1);
			}
			log.guardarTxt();
		}
	}
	
	/*
	@Override
	public boolean exitCalled() {
		System.out.println("se paro esta monda");
		return true;
	}*/

}
