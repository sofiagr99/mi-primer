import processing.core.PApplet;

public class Nieve extends Precipitacion {

	public Nieve(PApplet app, int cant) {
		super(app, cant);
		for (int i = 0; i < cant; i++) {
			particulas.add(new Gota(app, tam, 233,0,255));
		}
	}

	public void eliminar(float x, float y) {
		for (Particula particula : particulas) {
			if(PApplet.dist(particula.getDir().x, particula.getDir().y, x, y)<=30) {				
				particulas.remove(particula);
				return;
			}
		}
	}

}
