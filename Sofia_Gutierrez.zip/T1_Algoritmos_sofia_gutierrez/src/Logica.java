import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PVector;

public class Logica {

	private PApplet app;
	private int pantalla;
	private Lluvia lluvia;
	private Nieve nieve;
	private Tormenta tormenta;
	private Viento viento;
	private Flor flor;
	private Tornado tornado;
	private Huracan huracan;
	private Otono otono;
	private Verano ver;

	private String txt[];
	private StringBuffer out;

	private boolean Tormenta;

	public Logica(PApplet app) {
		this.app = app;
		pantalla = 0;
		Tormenta = false;

		out = new StringBuffer();  // buffer donde se grandaran los cambios del txt

		interpretarTxt();
	}
	
	/*
	 * lee el texto e interpreta la cantidad de objetos que debe crear segundo la cantidad de letras
	 * */

	public void interpretarTxt() {
		/*
		 * l = rayos de lluvia t = circulos en el viento f = petalos en la flor LA =
		 * Hexagonos por tornado EN = cuadros para huracan O = hojas de oto�o D =
		 * cantidad de soles CLIMA = copos de nieve
		 */
		int cl = 0, ct = 0, cf = 0, cla = 0, cen = 0, co = 0, cd = 0, cclima = 0;

		txt = app.loadStrings("../T1_Algoritmos_sofia_gutierrez/Data/Texto.txt");
		String l[] = txt[0].split(" ");
		for (int i = 0; i < l.length; i++) {
			if (l[i].contains("l"))
				cl++;
			if (l[i].contains("t"))
				ct++;
			if (l[i].contains("f"))
				cf++;
			if (l[i].contains("la"))
				cla++;
			if (l[i].contains("en"))
				cen++;
			if (l[i].contains("o"))
				co++;
			if (l[i].contains("d"))
				cd++;
			if (l[i].contains("clima"))
				cclima++;
		}

		lluvia = new Lluvia(app, 50);

		nieve = new Nieve(app, cclima);
		tormenta = new Tormenta(app, cl); //
		viento = new Viento(app, ct); //
		flor = new Flor(app, new PVector(app.width / 2, app.height / 2), cf); //
		tornado = new Tornado(app, new PVector(app.width / 2, app.height / 2 - 100), cla); //
		huracan = new Huracan(app, cen); //
		otono = new Otono(app, co); //
		ver = new Verano(app, cd); //

		out.insert(out.length(), txt[0]);
		// System.out.println(out);
		// System.out.println(cl + " " + ct + " " + cf + " " + cla + " " + cen + " " +
		// co + " " + cd + " " + cclima);
	}
	
	/*
	 * guarda en nu nuevo txt los cambios realizados por cada interaccion, el uso del hilo es para no pausar
	 * el ejecucion del hilo proincipal en el proceso de guardado
	 * */

	public void guardarTxt() {

		Thread h = new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("mdklsd");
				String[] guar = new String[1];
				String a = out.toString();
				guar[0] = a;
				app.saveStrings("../T1_Algoritmos_sofia_gutierrez/Data/cuento2.txt", guar);						
			}
		});
		h.start();
	}
	
	/*
	 * pintar cada uno de los casos de interaccion
	 * */

	public void ejecucion() {
		switch (pantalla) {
		case 0:
			lluvia.pintar();
			if (Tormenta)
				tormenta.pintar();
			break;

		case 1:
			viento.pintar();
			break;

		case 2:
			flor.pintar();
			break;

		case 3:
			tornado.pintar();
			break;

		case 4:
			huracan.pintar();
			huracan.act(new PVector(app.mouseX, app.mouseY));
			break;

		case 5:
			otono.pintar();
			break;

		case 6:
			ver.pintar();
			break;

		case 7:
			nieve.pintar();
			break;
		}
	}

	public void setPantalla(int i) {
		pantalla = i;
	}

	public int getPantalla() {
		return pantalla;
	}

	public boolean getTormenta() {
		return Tormenta;
	}

	public Tornado getTor() {
		return tornado;
	}

	public Otono getOto() {
		return otono;
	}

	/*
	 * interacciones con el teclado
	 */

	public void AgranVer(int i) {
		ver.agrandar(i);

		int a = out.indexOf("l");
		if (a != (-1))
			out.replace(a, a + 2, "  ");
	}

	public void moveOto(int x) {
		otono.mover(x);
		out.insert((int) app.random(out.length()), "interaccion chebere");
	}

	public void moveTor(PVector pVector) {
		tornado.setDir(pVector);

		int a = (int) app.random(out.length());
		int d = a;
		int b = (int) app.random(a, out.length());
		String c = "a";

		for (a = a; a <= b; a++) {
			c = c + out.charAt(a);
		}
		String e = c.toUpperCase();
		out.replace(d, b, e);
	}

	public void setTormenta(boolean i) {
		Tormenta = i;
		int a = out.indexOf("f");
		if (a != (-1))
			out.replace(a, a + 10, "granVerano");
	}

	public void girar() {
		flor.setGirarP(!flor.isGirarP());

		int a = (int) app.random(out.length());
		int d = a;
		int b = (int) app.random(a, out.length());
		String c = "a";

		for (a = a; a <= b; a++) {
			c = c + out.charAt(a);
		}
		String e = c.toLowerCase();
		out.replace(d, b, e);
	}

	/*
	 * interacciones generadas por el mouse
	 */

	public void valNieve() {
		nieve.eliminar(app.mouseX, app.mouseY);
		int a = (int) app.random(out.length());
		out.insert(a, "menos nieve");
	}

	public void valHuracan() {
		huracan.setPer(!huracan.isPer());
		out.reverse();
	}

	public void ventear() {
		viento.setVentear(!viento.getVentear());
		int a = (int) app.random(out.length());
		int b = (int) app.random(a, out.length());
		out.replace(a, b, " CLI ");
	}
}
