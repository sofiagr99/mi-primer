import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PVector;

public abstract class Precipitacion {

	protected ArrayList<Particula> particulas;
	protected PApplet app;
	protected int tam;

	public Precipitacion(PApplet app, int cant) {
		this.app = app;
		particulas = new ArrayList<Particula>();

		tam = 15;
	}

	public void pintar() {
		for (Particula particula : particulas) {
/*
			if (particula.getDir().y >= 700) {
				particula.setDir(new PVector(particula.getDir().x, -30));
			} */

			particula.pintar();
			particula.mover();
		}
	}

}
