import processing.core.PApplet;

public class Tormenta extends Precipitacion{

	public Tormenta (PApplet app, int cant) {
		super(app, cant);
		for (int i = 0; i <= cant; i++) {
			particulas.add(new Rayo(app, tam, 244, 226, 66));
		}
	}

}
