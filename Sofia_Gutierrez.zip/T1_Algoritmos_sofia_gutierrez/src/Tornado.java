import java.util.ArrayList;
import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PVector;

public class Tornado {

	private PApplet app;
	private PVector dir;
	private ArrayList<Tor> tors;

	public Tornado(PApplet app, PVector dir, int cant) {
		this.app = app;
		this.dir = dir;

		tors = new ArrayList<Tor>();

		for (int i = 0; i < cant; i++) {
			tors.add(new Tor(app, new PVector(dir.x, dir.y + (i * 20)-100)));
		}
	}

	public void pintar() {
		for (Tor t : tors) {
			t.pintar();
		}
	}

	public PVector getDir() {
		return dir;
	}

	public void setDir(PVector dir) {
		this.dir = dir;
		for (Tor tor : tors) {
			tor.setDir(dir);
		}
	}

	public class Tor {

		private PApplet app;
		private PVector dir;

		public Tor(PApplet app, PVector dir) {
			this.app = app;
			this.dir = dir;
		}

		public void pintar() {
			app.fill(239, 182, 19);
			poligono(dir.x, dir.y, 20, 6);
		}

		public void poligono(float x, float y, float radio, int npuntos) {
			float angle = PConstants.TWO_PI / npuntos;
			app.shapeMode(PApplet.CENTER);
			app.beginShape();
			for (float i = 0; i < PConstants.TWO_PI; i += angle) {
				float sx = x + PApplet.cos(i) * radio;
				float sy = y + PApplet.sin(i) * radio;
				app.vertex(sx, sy);
			}
			app.endShape(PConstants.CLOSE);
		}
		
		public PVector getDir() {
			return dir;
		}
		
		public void setDir(PVector dir) {
			this.dir = new PVector(dir.x, this.dir.y);
		}

	}

}
