import processing.core.PApplet;
import processing.core.PVector;

public class Verano extends Precipitacion {

	public Verano(PApplet app, int cant) {
		super(app, cant);
		
		for (int i = 0; i < cant; i++) {
			particulas.add(new HojaV(app, 50, 255, 212, 42));
		}
	}

	public void agrandar(int x) {
		for (Particula particula : particulas) {
			particula.setTam(particula.getTam()+x);
		}
	}
	
	public class HojaV extends Particula {

		public HojaV(PApplet app, int tam, int r, int g, int b) {
			super(app, tam, r, g, b);

			dir = new PVector(app.random(0,1200),app.random(0, 700));
		}
		
		@Override
		public void mover() {
			
		}
		
		public PVector getDir() {
			return dir;
		}
		
		public void setDir(PVector dir) {
			this.dir = new PVector(dir.x, this.dir.y);
		}
		
		
	}
}
