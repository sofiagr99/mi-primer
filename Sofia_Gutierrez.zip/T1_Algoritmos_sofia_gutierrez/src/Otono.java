
import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PVector;

public class Otono extends Precipitacion{

	public Otono(PApplet app, int cant) {
		super(app, cant);
		
		for (int i = 0; i <= cant; i++) {
			particulas.add(new Hoja(app, tam, 0,67,255));
		}
	}

	public void setDir(PVector dir) {
		for (Particula hoja : particulas) {
			hoja.setDir(dir);
		}
	}
	
	
	public void mover(int x) {
		for (Particula particula : particulas) {
			particula.setVel(particula.getVel()+x);
		}
	}
	
	
	public class Hoja extends Particula {

		public Hoja(PApplet app, int tam, int r, int g, int b) {
			super(app, tam, r, g, b);
		}
		
		@Override
		public void pintar() {
			app.rectMode(PConstants.CENTER);
			app.noStroke();
			app.fill(r,g,b,opa);
			app.rect(dir.x, dir.y, tam, tam);
		}
		
		public PVector getDir() {
			return dir;
		}
		
		public void setDir(PVector dir) {
			this.dir = new PVector(dir.x, this.dir.y);
		}
	}


}
