import processing.core.PApplet;

public class Lluvia extends Precipitacion {

	public Lluvia(PApplet app, int cant) {
		super(app, cant);
		for (int i = 0; i <= cant; i++) {
			particulas.add(new Gota(app, tam, 0,67,255));
		}
	}

}
