import processing.core.PApplet;

public class Rayo extends Particula {

	public Rayo(PApplet app, int tam, int r, int g, int b) {
		super(app, tam, r, g, b);
	}
	
	@Override
	public void pintar() {
		app.fill(r,g,b,opa);
		app.rect(dir.x, dir.y, 30, 100);
	}
	
	public void regresar() {
		if (dir.y >= 700) {
			dir.y=-100;
		}
	}
}
