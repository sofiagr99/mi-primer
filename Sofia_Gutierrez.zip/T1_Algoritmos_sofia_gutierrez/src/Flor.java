import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PVector;

public class Flor {
	
	private PApplet app;
	private PVector dir;
	private ArrayList<Petalo> petalos;
	private boolean girarP; 
	
	public  Flor(PApplet app, PVector dir, int cant) {
		this.app=app;
		this.dir=dir;
		petalos =  new ArrayList<Petalo>();
		girarP = false;
		
		for (int i = 0; i < cant; i++) {
			petalos.add(new Petalo(app, new PVector(-50,-50), PConstants.PI/i,i/60));
		}
	}
	
	public void pintar() {
		for (Petalo petalo : petalos) {
			petalo.pintar();
			if(girarP) {
				petalo.mover();
			}
		}
		app.noStroke();
		app.fill(94, 75, 21);
		app.ellipse(dir.x, dir.y, 50, 50);
	}
	
	public boolean isGirarP() {
		return girarP;
	}

	public void setGirarP(boolean girarP) {
		this.girarP = girarP;
	}



	public class Petalo{
		
		private PApplet app;
		private PVector dir;
		private float i, m;

		public Petalo(PApplet app, PVector dir, float m, float i) {
			this.app=app;
			this.dir=dir;
			this.m=m;
			this.i=i;
			i=(float) (0.0 - 1/60.0);
		}
		
		public void pintar() {
			app.fill(244, 197, 66);
			app.ellipse(dir.x, dir.y, 10, 10);
		}
		
		public void mover() {
			dir.x = app.width/2+(100 * PApplet.cos(m * i));
			dir.y = app.height/2 + (100 * PApplet.sin(m * i));
			i+=1/60.0;			
		}
	}
}
